﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2._2._7
{
    public class MetodosAUX
    {
        public static int id = 0;
        public static Programador[] programador = new Programador[0];
    }
}
